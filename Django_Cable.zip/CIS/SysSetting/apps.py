from django.apps import AppConfig


class SyssettingConfig(AppConfig):
    name = 'SysSetting'
    verbose_name = "系统设置"
